from temporalio import activity
from python_models.agentic_models import NLToSQLResult
from typing import Dict, Any

@activity.defn
async def generate_sql(nl_query: str, schema: str) -> str:
    """Generate SQL via NL->SQL agent (stub) and validate result using Pydantic NLToSQLResult model."""
    example = {
        "query_id": "q-validated-1",
        "sql": "SELECT 1 as one LIMIT 1;",
        "explanation": f"Generated SQL for: {nl_query}",
        "safety": {"safe": True, "reasons": ["read-only","limit"], "score": 0.99}
    }
    try:
        validated = NLToSQLResult.parse_obj(example)
    except Exception as e:
        raise RuntimeError(f"NL->SQL validation failed: {e}")
    return validated.sql
