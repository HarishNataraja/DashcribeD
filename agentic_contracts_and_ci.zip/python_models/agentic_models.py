from __future__ import annotations
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, confloat
from datetime import datetime

class SafetyInfo(BaseModel):
    safe: bool
    reasons: List[str]
    score: Optional[confloat(ge=0.0, le=1.0)] = None

class Estimate(BaseModel):
    row_count_estimate: Optional[int] = None
    cost_estimate_usd: Optional[float] = None

class NLToSQLResult(BaseModel):
    query_id: str
    sql: str
    parameterized_sql: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None
    explanation: str
    safety: SafetyInfo
    estimate: Optional[Estimate] = None
    preview_query: Optional[str] = None
    llm_metadata: Optional[Dict[str, Any]] = None
    provenance: Optional[Dict[str, Any]] = None
