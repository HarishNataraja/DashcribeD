import { z } from "zod";
export const FilterSchema = z.object({
  column: z.string(),
  op: z.enum(["=" , ">" , "<" , ">=" , "<=" , "in" , "not in" , "between" , "contains"]),
  value: z.any()
});
export const DateRangeSchema = z.object({
  start: z.string().optional(),
  end: z.string().optional(),
  relative: z.enum(["last_7_days","last_30_days","ytd","last_quarter","custom"]).optional()
});
export const NLIntentSchema = z.object({
  intent_id: z.string(),
  user_id: z.string().nullable().optional(),
  user_query: z.string(),
  timestamp: z.string(),
  intent: z.enum(["explore","chart","compare","forecast","root_cause","export","presentation","other"]),
  metric: z.string().nullable().optional(),
  group_by: z.array(z.string()).optional(),
  filters: z.array(FilterSchema).optional(),
  date_range: DateRangeSchema.optional().nullable(),
  viz_type_hint: z.union([z.literal("table"),z.literal("line"),z.literal("bar"),z.literal("pie"),z.literal("area"),z.literal("scatter"),z.literal("box"),z.literal("heatmap"),z.literal("flowchart"),z.literal("mindmap"),z.literal("diagram")]).optional().nullable(),
  confidence: z.number().min(0).max(1).optional(),
  clarification_required: z.boolean().optional(),
  raw_extras: z.record(z.any()).optional()
});
export const SafetyInfoSchema = z.object({
  safe: z.boolean(),
  reasons: z.array(z.string()),
  score: z.number().min(0).max(1).optional()
});
export const EstimateSchema = z.object({
  row_count_estimate: z.number().int().optional().nullable(),
  cost_estimate_usd: z.number().optional().nullable()
});
export const NLToSQLResultSchema = z.object({
  query_id: z.string(),
  sql: z.string(),
  parameterized_sql: z.string().optional().nullable(),
  parameters: z.record(z.any()).optional().nullable(),
  explanation: z.string(),
  safety: SafetyInfoSchema,
  estimate: EstimateSchema.optional(),
  preview_query: z.string().optional().nullable(),
  llm_metadata: z.record(z.any()).optional(),
  provenance: z.record(z.any()).optional()
});
export const ChartSpecSchema = z.object({
  chart_id: z.string(),
  type: z.enum(["histogram","line","bar","box","scatter","heatmap","table","pie"]),
  title: z.string(),
  columns: z.array(z.string()).optional(),
  spec: z.record(z.any()).optional()
});
export const EDAMetricsSchema = z.object({
  row_count: z.number().int().optional(),
  column_count: z.number().int().optional(),
  numeric_columns: z.number().int().optional(),
  categorical_columns: z.number().int().optional()
});
export const EDAReportSchema = z.object({
  report_id: z.string(),
  workspace_id: z.string().nullable().optional(),
  generated_at: z.string(),
  summary: z.string(),
  charts: z.array(ChartSpecSchema),
  missingness: z.array(z.object({
    column: z.string(),
    missing_pct: z.number().min(0).max(100),
    suggestion: z.string().optional()
  })).optional(),
  correlations: z.array(z.object({
    pair: z.tuple([z.string(), z.string()]),
    corr: z.number(),
    note: z.string().optional()
  })).optional(),
  anomalies: z.array(z.object({
    column: z.string(),
    example_row: z.record(z.any()).optional(),
    note: z.string().optional()
  })).optional(),
  metrics: EDAMetricsSchema,
  provenance: z.record(z.any()).optional()
});
export const SlideSchema = z.object({
  index: z.number().int(),
  title: z.string(),
  bullets: z.array(z.string()),
  chart_ids: z.array(z.string()).optional(),
  notes: z.string().optional(),
  layout_hint: z.enum(["title_left_chart_right","title_top_chart_bottom","two_column","full_width_chart","text_only","comparison"]).optional()
});
export const SlideOutlineSchema = z.object({
  outline_id: z.string(),
  created_by: z.string().nullable().optional(),
  created_at: z.string(),
  title: z.string().optional(),
  slides: z.array(SlideSchema),
  metadata: z.record(z.any()).optional()
});
export const HypothesisSchema = z.object({
  hypothesis_id: z.string(),
  description: z.string(),
  validation_sql: z.string(),
  validation_preview: z.record(z.any()).optional(),
  stats: z.record(z.any()).optional(),
  status: z.enum(["pending","validated","rejected","inconclusive"]).optional()
});
export const RootCauseHypothesisSchema = z.object({
  insight_id: z.string(),
  generated_at: z.string(),
  hypotheses: z.array(HypothesisSchema),
  recommendation: z.string().optional(),
  provenance: z.record(z.any()).optional()
});
