from fastapi import FastAPI, HTTPException
from python_models.agentic_models import NLIntent, NLToSQLResult, EDAReport, SlideOutline, RootCauseHypothesis
from typing import Any

app = FastAPI(title="Agentic Platform API", version="0.1.0")

@app.get("/")
def root():
    return {"service": "agentic-api", "status": "ok"}

@app.post("/validate/intent", response_model=NLIntent)
def validate_intent(payload: Any):
    try:
        obj = NLIntent.parse_obj(payload)
        return obj
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))

@app.post("/validate/nl_to_sql", response_model=NLToSQLResult)
def validate_nl_to_sql(payload: Any):
    try:
        obj = NLToSQLResult.parse_obj(payload)
        return obj
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))

@app.post("/validate/eda", response_model=EDAReport)
def validate_eda(payload: Any):
    try:
        obj = EDAReport.parse_obj(payload)
        return obj
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))

@app.post("/validate/outline", response_model=SlideOutline)
def validate_outline(payload: Any):
    try:
        obj = SlideOutline.parse_obj(payload)
        return obj
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))

@app.post("/validate/rootcause", response_model=RootCauseHypothesis)
def validate_rootcause(payload: Any):
    try:
        obj = RootCauseHypothesis.parse_obj(payload)
        return obj
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
