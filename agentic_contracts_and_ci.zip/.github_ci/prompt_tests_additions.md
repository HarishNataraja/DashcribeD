# CI additions - snippets to add to your prompt-tests.yml

# AJV validation step
- name: Run AJV validations
  run: |
    cd node_validator
    npm ci
    node validator.js ../schemas/nl_to_sql_result.json ../samples/golden_nl_to_sql.json

# Zod (frontend) check - create frontend/scripts/check_golden_with_zod.js that imports zod schemas and validates samples
- name: Run Zod checks (frontend)
  run: |
    cd frontend
    npm ci
    node ./scripts/check_golden_with_zod.js

# Python FastAPI smoke test (optional)
- name: FastAPI smoke (validate with pydantic)
  run: |
    python -m venv .venv
    . .venv/bin/activate
    pip install -r python_api/requirements.txt
    python -c "import requests, json; print('skipping live call in CI')"
