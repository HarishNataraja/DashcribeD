Agentic contracts & CI package

This archive contains:
- node_validator/: AJV-based CLI validator and Express middleware
- python_api/: FastAPI app that validates payloads using Pydantic models
- frontend/zod_schemas/: Zod schemas for frontend runtime validation
- schemas/: JSON Schemas used by AJV
- samples/: golden sample JSON payloads
- .github_ci/: CI snippet suggestions to wire into your GitHub Actions
- temporal_updates/: small Temporal activity update that validates NL->SQL via Pydantic

How to use:
- Copy relevant folders into your repo
- Wire AJV or FastAPI into your orchestration to validate agent outputs at runtime
- Add CI snippets to your existing workflows to run validation on PRs
