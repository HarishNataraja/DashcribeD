import express from "express";
import fs from "fs";
import Ajv from "ajv";
import addFormats from "ajv-formats";

const app = express();
app.use(express.json({ limit: "2mb" }));

const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

function loadSchema(filename) {
  const schema = JSON.parse(fs.readFileSync(`../schemas/${filename}`, "utf8"));
  return ajv.compile(schema);
}

const validators = {
  "nl_to_sql_result": loadSchema("nl_to_sql_result.json"),
  "eda_report": loadSchema("eda_report.json"),
  "nl_intent": loadSchema("nl_intent.json"),
  "slide_outline": loadSchema("slide_outline.json")
};

function validationMiddleware(schemaKey) {
  return (req, res, next) => {
    const validate = validators[schemaKey];
    if (!validate) return res.status(500).json({ error: "No schema" });
    const valid = validate(req.body);
    if (!valid) return res.status(400).json({ errors: validate.errors });
    next();
  };
}

app.post("/webhook/nl_to_sql_result", validationMiddleware("nl_to_sql_result"), (req, res) => {
  res.json({ ok: true });
});

app.post("/webhook/eda_report", validationMiddleware("eda_report"), (req, res) => {
  res.json({ ok: true });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Validator server listening on ${port}`));
