import fs from "fs";
import Ajv from "ajv";
import addFormats from "ajv-formats";

const [,, schemaPath, samplePath] = process.argv;

if (!schemaPath || !samplePath) {
  console.error("Usage: node validator.js <schema.json> <sample.json>");
  process.exit(2);
}

const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

const schema = JSON.parse(fs.readFileSync(schemaPath, "utf8"));
const data = JSON.parse(fs.readFileSync(samplePath, "utf8"));

const validate = ajv.compile(schema);
const valid = validate(data);

if (valid) {
  console.log("✅ VALID");
  process.exit(0);
} else {
  console.error("❌ INVALID:");
  console.error(validate.errors);
  process.exit(1);
}
